module com.example.controllsdemo {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.controllsdemo to javafx.fxml;
    exports com.example.controllsdemo;
}