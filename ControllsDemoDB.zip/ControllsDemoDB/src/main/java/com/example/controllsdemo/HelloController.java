package com.example.controllsdemo;

import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import model.Person;

import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    private SimpleListProperty listProperty = new SimpleListProperty();
    private ObservableList<Person> persons = FXCollections.observableArrayList(
            new Person(1,"Stefan","Müller",1995,"AUT"),
            new Person(2,"Jürgen","Huber",1990,"DE"),
            new Person(3,"Lukas","Mayer",1989 ,"IT")
    );

    @FXML
    private ComboBox<Person> cbPersons;
    @FXML
    private TextField tfFirstName;
    @FXML
    private TextField tfLastName;
    @FXML
    private Button btnSave;
    @FXML
    private MenuItem miEdit;
    @FXML
    private Spinner<Integer> spYob;
    @FXML
    private ToggleGroup tgCountrys;
    @FXML
    private RadioButton rbIt;
    @FXML
    private RadioButton rbDe;
    @FXML
    private RadioButton rgAut;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        cbPersons.itemsProperty().bind(listProperty);
        listProperty.setValue(persons);

        spYob.setValueFactory(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1958,2005)
       );
    }

    @FXML
    public void handleCbPersonsAction(ActionEvent actionEvent) {
        Person p = cbPersons.getSelectionModel().getSelectedItem();
        System.out.println(p.getId() +" "+ p);
    }

    @FXML
    public void handleMiEditAction(ActionEvent actionEvent) {
        Person p = cbPersons.getSelectionModel().getSelectedItem();
        if (p == null)
            return;

        tfFirstName.setText(p.getFirstname());
        tfLastName.setText(p.getLastname());
        spYob.getValueFactory().setValue(p.getBirthyear());

        for (Toggle tg: tgCountrys.getToggles()) {
            if (((RadioButton)tg).getText().equals(p.getCountry()))
                tgCountrys.selectToggle(tg);
        }
    }

    @FXML
    public void handleBtnSaveAction(ActionEvent actionEvent) {
        Person p = cbPersons.getSelectionModel().getSelectedItem();

        if (p ==null)
            return;

        p.setFirstname(tfFirstName.getText());
        p.setLastname(tfLastName.getText());
        p.setBirthyear((Integer) spYob.getValue());
        p.setCountry(((RadioButton)tgCountrys.getSelectedToggle()).getText());

        int x = cbPersons.getSelectionModel().getSelectedIndex();
        persons.set(x,p);
    }
}